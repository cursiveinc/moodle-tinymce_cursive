
/**
 * @module     tiny_cursive/plugin
 * @category TinyMCE Editor
 * @copyright  CTI <info@cursivetechnology.com>
 * @author kuldeep singh <mca.kuldeep.sekhon@gmail.com>
 */


const component = 'tiny_cursive';

export default {
    component,
    pluginName: `${component}/plugin`,
};
